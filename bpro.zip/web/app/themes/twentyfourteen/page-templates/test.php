<?php
/* Template Name: Test */

get_header();

echo do_shortcode('[show_user_roles]');

get_footer();
