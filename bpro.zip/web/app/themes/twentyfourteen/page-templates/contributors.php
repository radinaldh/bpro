<?php

/**
 * Template Name: Example Template
 */

get_header('main'); ?>

<?php
get_footer('main');
